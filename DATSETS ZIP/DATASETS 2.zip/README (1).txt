Hospital synthetic dataset generated on 2025-11-26T13:55:06.012158.
Location: /mnt/data/hospital_dataset_large

Row counts:
departments: 20
doctors: 2000
patients: 200000
rooms: 5000
appointments: 700000
admissions: 30000
treatments: 80000
medications: 500
prescriptions: 150000
lab_tests: 100
lab_results: 100000
invoices: 150000
invoice_lines: 300000

Total rows across major tables: 1480000
